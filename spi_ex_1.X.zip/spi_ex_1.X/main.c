/*
 * File:   main.c
 * Author: Admin
 *
 * Created on February 6, 2024, 9:16 PM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  8000000UL

void spi_init(void){
    /*SPI Mode Clock Low To High*/
    SSPCONbits.CKP=0;
    SSPSTATbits.CKE=1;
    SSPSTATbits.SMP=0;
    /*SPI Master Mode Clock = Fosc/64*/
    SSPCONbits.SSPM=2;
    /*Turn On The Module*/
    SSPCONbits.SSPEN=1;
    SSPSTATbits.BF=1;
}

void main(void) {
    OSCCONbits.IRCF=7;
    spi_init();
    PORTC=0;
    TRISC=0;
    TRISC4=1;
    while(1){
        SSPBUF=0xF0;
        __delay_us(80);
        RC2=1;
        __delay_us(10);
        RC2=0;
        __delay_ms(1000);
        
        SSPBUF=0x0F;
         __delay_us(80);
        RC2=1;
        __delay_us(10);
        RC2=0;
        __delay_ms(1000);
        
        SSPBUF=0xAA;
         __delay_us(80);
        RC2=1;
        __delay_us(10);
        RC2=0;
        __delay_ms(1000);
    }
    return;
}
