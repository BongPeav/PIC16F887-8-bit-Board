/*
 * File:   main.c
 * Author: Admin
 *
 * Created on February 13, 2024, 3:49 PM
 */

#include <xc.h>
#include "config.h"
#include "LCD4Bits.h"
#include "spi.h"

#define _XTAL_FREQ  8000000UL

void write_25AA010(uint8_t address, uint8_t data){
    /*Write Enable Command*/
    nCS=0;
    spi_send(0x06);
    nCS=1;
    /*Write Process*/
    nCS=0;
    spi_send(0x02);
    spi_send(address);
    spi_send(data);
    nCS=1;
    /*EEPROM Write Time*/
    __delay_ms(10);
}

void write_text(uint8_t start, uint8_t *txt){
    uint8_t addr=0;
    while(*txt){
        write_25AA010(start+addr,*txt++);
        addr++;
    }
}

uint8_t read_25AA010(uint8_t address){
    uint8_t data;
    nCS=0;
    spi_send(0x03);
    spi_send(address);
    data=spi_receive();
    nCS=1;
    return data;
}

void main(void) {
    OSCCONbits.IRCF=7;
    lcdInit();
    spi_init();
    
    uint8_t data;
    uint8_t txt[]="PIC16F887 24AA010A";
    write_text(0,txt);
    for(uint8_t i=0;i<sizeof(txt)-1;i++){
        data=read_25AA010(i);
        lcdData(data);
    }
    
    PORTB=0;
    TRISB=0;
    ANSELH=0;
    while(1){
        for(uint8_t i=0;i<8;i++){
            write_25AA010(20+i,1<<i);
            PORTB=read_25AA010(20+i);
            __delay_ms(100);
        }
        __delay_ms(1000);
        for(int8_t i=7;i>=0;i--){
            write_25AA010(40-i,1<<i);
            PORTB=read_25AA010(40-i);
            __delay_ms(100);
        }
        __delay_ms(1000);
    }
    return;
}
