/* 
 * File:   spi.h
 * Author: Admin
 *
 * Created on February 9, 2024, 9:13 AM
 */

#include <xc.h>

#define WRITE_ADDR  0x40
#define READ_ADDR   0x41

#define nCS     RC2

void spi_init(void);
void spi_send(uint8_t data);
uint8_t spi_receive(void);

