/*
 * File:   main.c
 * Author: Admin
 *
 * Created on February 12, 2024, 7:19 PM
 */

#include <xc.h>
#include <stdio.h>
#include "config.h"
#include "LCD4Bits.h"
#include "spi.h"

#define _XTAL_FREQ  8000000UL

void putch(char data){
    lcdData(data);
}

void dec_to_bin(uint8_t data){
    for(int8_t i=7;i>=0;i--){
        if((data&(1<<i))==0) putch('0');
        else putch('1');
    }
}

void main(void) {
    uint8_t rc_data;
    OSCCONbits.IRCF=7;
    lcdInit();
    spi_init();
    lcdCommand(0x0C);
    nCS=1;
    while(1){
        nCS=0;
        __delay_us(10);
        nCS=1;
        rc_data=spi_receive();
        lcdXY(1,1); 
        printf("DEC:%3d",rc_data);
        printf(" HEX:0x%02X",rc_data);
        lcdXY(1,2); 
        printf("BIN: ");
        dec_to_bin(rc_data);
        __delay_ms(100);
    }
    return;
}
