/*
 * File:   main.c
 * Author: Admin
 *
 * Created on February 9, 2024, 9:10 AM
 */

#include <xc.h>
#include "config.h"
#include "spi.h"

#define _XTAL_FREQ  8000000UL

void mcp23S17_send(uint8_t address, uint8_t data){
    nCS=0;
    spi_send(WRITE_ADDR);
    spi_send(address);
    spi_send(data);
    nCS=1;
}

uint8_t mcp23S17_receive(uint8_t address){
    uint8_t data;
    nCS=0;
    spi_send(READ_ADDR);
    spi_send(address);
    data=spi_receive();
    nCS=1;  
    return data;
}

void mcp23S17_init(void){
    nCS=1;
    mcp23S17_send(0x0A,0x08);   // Enable Address Select
    mcp23S17_send(0x0B,0x08);   // Enable Address Select
    mcp23S17_send(0x00,0xFF);   // GPIOA AS INPUT
    mcp23S17_send(0x0C,0xFF);    // Enable All GPPUA
    mcp23S17_send(0x01,0x00);   // GPIOB AS OUTPUT
}

void main(void) {
    uint8_t data;
    OSCCONbits.IRCF=7;
    spi_init();
    mcp23S17_init();
    while(1){
        data=mcp23S17_receive(0x12);
        mcp23S17_send(0x15,data);
        __delay_ms(150);
    }
    return;
}
