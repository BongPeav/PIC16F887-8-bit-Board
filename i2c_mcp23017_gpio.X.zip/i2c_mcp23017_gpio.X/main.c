/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 21, 2024, 3:07 PM
 */

#include <xc.h>
#include "config.h"
#include "i2c.h"

#define _XTAL_FREQ  8000000UL

#define MCP23017_W  0x40
#define MCP23017_R  0x41

void mcp23017_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

void main(void) {
    OSCCONbits.IRCF=7;
    i2c_init(400000);
    mcp23017_write(0,0);
    while(1){
        uint8_t i=0;
        while(i<8){
            mcp23017_write(0x14,1<<i);
            i++;
            __delay_ms(100);
        }
    }
    return;
}
