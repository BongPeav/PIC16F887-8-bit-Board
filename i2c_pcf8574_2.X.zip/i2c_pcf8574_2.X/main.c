/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 15, 2024, 8:17 PM
 */


#include <xc.h>
#include "config.h"
#include "i2c.h"

#define _XTAL_FREQ  8000000UL
#define PCF8574_W   0x40
#define PCF8574_R   0x41

void pcf8574Write(uint8_t data){
    i2c_start();
    i2c_write(PCF8574_W);
    i2c_write(0x20);
    i2c_write(data);
    i2c_stop();
}

uint8_t pcf8574Read(){
    uint8_t data;
    pcf8574Write(0xFF);
    
    i2c_start();
    i2c_write(PCF8574_R);
    data=i2c_read(0);
    i2c_stop();
    return data;
}
void main(void) {
    OSCCONbits.IRCF=7;
    i2c_init(100000);
    PORTD=0;
    TRISD=0;
    while(1){
        PORTD=pcf8574Read();
        __delay_ms(200);
    }
    return;
}
