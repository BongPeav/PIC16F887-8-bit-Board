/*
 * File:   mcp23017.c
 * Author: Admin
 *
 * Created on January 21, 2024, 7:14 PM
 */

#include "mcp23017.h"

void mcp23017_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t mcp23017_read(uint8_t address){
    uint8_t data;
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_stop();
    
    i2c_start();
    i2c_write(MCP23017_R);
    data=i2c_read(0);
    i2c_stop();
    return data;
}

/*Key Pad Functions Section*/
void keyboard_init(void){
    mcp23017_write(IODIRB,0xF0);
    mcp23017_write(GPPUB,0x0F);
}

void mcp23017_init(void){
    i2c_init(400000);
    mcp23017_write(IODIRA,0);
    keyboard_init();
}

uint8_t keyScan(void){
    uint8_t data,temp;
    for(uint8_t i=0;i<4;i++){
        data=1<<i;
        mcp23017_write(OLATB,data);
        __delay_ms(10);
        data=mcp23017_read(GPIOB);
        data>>=4;
        if(data==0x01) {temp=ascii_16[i][0]; break;}
        else if(data==0x02) {temp=ascii_16[i][1]; break;}
        else if(data==0x04) {temp=ascii_16[i][2]; break;}
        else if(data==0x08) {temp=ascii_16[i][3]; break;}
        else temp=0xFF;
        __delay_ms(10);
    }
    return temp;
}

/*4-bit character LCD Section*/

void lcd_command(uint8_t temp){
    uint8_t command,led;
    command=temp&0xF0;
    if(BLK_ON==1) led=0x08;
    else led=0;
    mcp23017_write(OLATA,command|led|(1<<EN));
    __delay_us(10);
    mcp23017_write(OLATA,command|led);
    __delay_us(25);
    
    command=temp<<4;
    mcp23017_write(OLATA,command|led|(1<<EN));
    __delay_us(10);
    mcp23017_write(OLATA,command|led);
    __delay_us(25);
}

void lcd_data(uint8_t temp){
    uint8_t data,led;
    data=temp&0xF0;
    if(BLK_ON==1) led=0x08;
    else led=0;
    mcp23017_write(OLATA,data|led|(1<<EN)|(1<<RS));
    __delay_us(10);
    mcp23017_write(OLATA,data|led|(1<<RS));
    __delay_us(25);
    
    data=temp<<4;
    mcp23017_write(OLATA,data|led|(1<<EN)|(1<<RS));
    __delay_us(10);
    mcp23017_write(OLATA,data|led|(1<<RS));
    __delay_us(25);
}

void lcd_xy(uint8_t x, uint8_t y){
    uint8_t cursor[]={0x80,0xC0};
    lcd_command(cursor[y-1]+x-1);
}

void lcd_text(uint8_t *text){
    while(*text) lcd_data(*text++);
}

void lcd_clear(void){
    lcd_command(0x01);
    __delay_ms(5);
}

void lcd_init(void){
    BLK_ON=1;
    mcp23017_init();
    lcd_command(0x33);
    __delay_us(10);
    lcd_command(0x32);
    __delay_us(10);
    lcd_command(0x28);
    __delay_us(10);
    lcd_command(0x0F);
    __delay_us(10);
    lcd_command(0x01);
    __delay_ms(5);
    lcd_command(0x06);
    __delay_us(10);
}