/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H
#endif

#include <xc.h> // include processor files - each processor file is guarded.  
#include "i2c.h"

#define MCP23017_W  0x40
#define MCP23017_R  0x41

#define IODIRA      0x00
#define IODIRB      0x01
#define GPPUB       0x0D
#define GPIOA       0x12
#define GPIOB       0x13
#define OLATA       0x14
#define OLATB       0x15

/*Key Pad Section*/
/*Common Cathode Display*/
const uint8_t d_7[]={0x3F,0x06,0x5B,0x4F,
                     0x66,0x6D,0x7D,0x07,
                     0x7F,0x6F,0x77,0x7C,
                     0x39,0x5E,0x79,0x71};

/*ASCII Characters*/
const uint8_t ascii_16[][4]={'7','8','9','F',
                          '4','5','6','E',
                          '1','2','3','D',
                          'A','0','B','C'};
/*4x4 Matrix Keypad Map*/
const uint8_t key_16[][4]={7,8,9,15,
                           4,5,6,14, 
                           1,2,3,13,
                           10,0,11,12};
/*For Character LCD 4-bit*/
const char RS=0,RW=1,EN=2;
__bit BLK_ON=0;

void mcp23017_write(uint8_t address, uint8_t data);
uint8_t mcp23017_read(uint8_t address);
void mcp23017_init(void);

uint8_t keyScan(void);

/*Character LCD Function Prototype*/
void lcd_command(uint8_t temp);
void lcd_data(uint8_t temp);
void lcd_xy(uint8_t x, uint8_t y);
void lcd_text(uint8_t *text);
void lcd_clear(void);
void lcd_init(void);