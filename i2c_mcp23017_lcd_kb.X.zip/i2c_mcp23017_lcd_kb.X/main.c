/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 22, 2024, 9:04 AM
 */

#include <xc.h>
#include "config.h"
#include "mcp23017.h"

#define _XTAL_FREQ  8000000

void main(void) {
    OSCCONbits.IRCF=7;
    __delay_ms(100);
    lcd_init();
    __delay_ms(100);
    lcd_text("  MCP23017 I2C");
    lcd_xy(1,2);
    lcd_text("  LCD Key Pad");
    __delay_ms(3000);
    lcd_clear();
    uint8_t temp,counter=0,new_line=0,line_num=1;
    while(1){
        temp=keyScan();
        if(temp!=0xFF){
            lcd_data(temp);
            counter++;
            __delay_ms(250);
        }
        if(counter>=16) {counter=0; new_line=1;}
        if(new_line){
            new_line=0;
            line_num++;
            if(line_num==2) lcd_xy(1,2);
            if(line_num==3){lcd_clear(); line_num=1;}
        }
    }
    return;
}
