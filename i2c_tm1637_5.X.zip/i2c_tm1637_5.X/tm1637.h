/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

#include <xc.h>

#define CLK RD0
#define DIO RD1
#define DIO_DIR TRISD1
#define ADDR_AUTO   0x40
#define ADDR_FIXED  0x44
#define STARTADDR   0xC0
#define DISPLAY_ON  0x88
#define LOW_BRIGHT      DISPLAY_ON+0
#define MEDIUM_BRIGHT   DISPLAY_ON+4
#define HIGH_BRIGHT     DISPLAY_ON+7

const uint8_t data_7[]={0x3F,0x06,0x5B,0x4F,
                        0x66,0x6D,0x7D,0x07,
                        0x7F,0x6F,0x77,0x7C,
                        0x39,0x5E,0x79,0x71};

void start(void);
void stop(void);
void writeByte(int8_t data);
void display(int8_t address, int8_t data);
void clearDisplay(void);
void TM1637Init(void);
char scanKey(void);
char readByte(void);
char findKey(char data);