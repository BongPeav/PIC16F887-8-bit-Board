/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 14, 2024, 5:51 PM
 */

#include <xc.h>
#include "config.h"
#include "tm1637.h"

#define _XTAL_FREQ  8000000UL

void main(void) {
    char data=0;
    char txt[7];
    OSCCONbits.IRCF=7;
    TM1637Init();
    PORTC=0;
    TRISC=0;
    display(1,data_7[1]);
    display(2,data_7[6]);
    display(3,data_7[3]);
    display(4,data_7[7]);
    __delay_ms(2500); 
    clearDisplay();
    while(1){
        data=scanKey();
        if(data!=0xFF) {
            PORTC=data;
            txt[6]=data_7[findKey(data)];
            for(uint8_t i=0;i<6;i++) txt[i]=txt[i+1];
            for(uint8_t i=0;i<6;i++) display(i,txt[i]);
            __delay_ms(250);
        }         
    }
    return;
}
