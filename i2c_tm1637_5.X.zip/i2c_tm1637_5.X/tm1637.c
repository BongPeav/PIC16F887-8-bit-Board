/*
 * File:   tm1637.c
 * Author: Admin
 *
 * Created on January 11, 2024, 9:31 PM
 */

#include "tm1637.h"
void myDelay(uint16_t time){
    while(time) time--;
}
void start(void){
    CLK=1;
    DIO=1;
    DIO=0;
    CLK=0;
}
void stop(void){
    CLK=0;
    DIO=0;
    CLK=1;
    DIO=1;
}

void writeByte(int8_t data){
    uint8_t i, count1;
    for(i=0;i<8;i++){
        CLK=0;
        if(data&0x01) DIO=1;
        else DIO=0;
        data>>=1;
        CLK=1;
    }
    CLK=0;
    //DIO=1;
    CLK=1;
    DIO_DIR=1;
    while(DIO==1){
        count1+=1;
        if(count1==200){
            DIO_DIR=0;
            DIO=0;
            count1=0;
        }
        DIO_DIR=1;
    }
    DIO_DIR=0;
}

void display(int8_t address, int8_t data){
    start();
    writeByte(ADDR_FIXED);
    stop();
    start();
    writeByte(STARTADDR|address);
    writeByte(data);
    stop();
    start();
    writeByte(MEDIUM_BRIGHT);
    stop();
}

void clearDisplay(void){
    for(int8_t i=0;i<6;i++) display(i,0);
}

char readByte(void){
    uint8_t i, count1;
    uint8_t data=0;
    DIO_DIR=1;
    DIO=0;
    for(i=0;i<8;i++){
        CLK=0;
        if(DIO==1) data|=(1<<i);      
        //if(DIO==1) data|=(1<<(7-i)); 
        CLK=1;
    }
    CLK=0;
    DIO=1;
    CLK=1;
    DIO_DIR=1;
    while(DIO==1){
        count1+=1;
        if(count1==200){
            //DIO_DIR=0;
            DIO=0;
            count1=0;
        }
      //  DIO_DIR=1;
    }
    DIO_DIR=0;
    return data;
}

char scanKey(void){
    char temp;
    start();
    writeByte(0x42); 
    start();
    temp=readByte();
    stop();
    //__delay_ms(10);
    myDelay(5000);
    return temp;
}

char findKey(char data){
    char myKey;
    switch(data){
        case 0xF7:    myKey=12;   break;     //1110_1111
        case 0xF6:    myKey=13;   break;     //0110_1111
        case 0xF5:    myKey=14;   break;     //1010_1111
        case 0xF4:    myKey=15;   break;     //0010_1111
        /**********************************************/
        case 0xEF:    myKey=8;    break;    //1111_0111
        case 0xEE:    myKey=9;    break;    //0111_0111
        case 0xED:    myKey=10;   break;    //1011_0111
        case 0xEC:    myKey=11;   break;    //0011_0111
        /**********************************************/
        case 0xEB:    myKey=4;    break;    //1101_0111
        case 0xEA:    myKey=5;    break;    //0101_0111
        case 0xE9:    myKey=6;    break;    //1001_0111
        case 0xE8:    myKey=7;    break;    //0001_0111
        /**********************************************/
        case 0xF3:    myKey=0;    break;    //1100_1111
        case 0xF2:    myKey=1;    break;    //0100_1111
        case 0xF1:    myKey=2;    break;    //1000_1111
        case 0xF0:    myKey=3;    break;    //0000_1111
    }    
    return myKey;
}

void TM1637Init(void){
    PORTD=0;
    TRISD=0;
    DIO=1;
    CLK=1;
    clearDisplay();
}

