/*
 * File:   main.c
 * Author: Admin
 *
 * Created on December 28, 2023, 9:51 PM
 */

#include <xc.h>
#include "config.h"
#include "lcd.h"

#include <stdio.h>

#define _XTAL_FREQ  8000000UL

#define TRIGGER RD6
#define ECHO    RD7

volatile uint8_t T0OV=0;
volatile uint16_t myCounter=0;
volatile uint16_t getDistance=0, temp=0;

void __interrupt() T0_ISR(){
    if(T0IF==1){
        T0OV+=1;
        myCounter++;
        T0IF=0;
    }
}

void readDistance(void){
    char msg[8];
    TRIGGER=1;
    __delay_us(10);
    TRIGGER=0;
    __delay_us(30);
    while(ECHO==0){
        /*Waiting For High Pulse Response, Or Sensor Present*/
        temp++;
        __delay_us(10);
        if(temp>=20) break;
    }
    TMR0=0;
    T0OV=0;
    while(ECHO==1);
    temp=(T0OV<<8)+TMR0+14;
    getDistance=temp/58;
    
    lcdXY(5,4);
    sprintf(msg,"%4d %cS  ",temp,228);
    lcdString(msg);
    lcdXY(5,2);
    if(temp>=116&&getDistance<=400){
        sprintf(msg,"%3d",getDistance);
        lcdString(msg);
        
        temp%=58;
        temp=(temp*100)/58;     
        sprintf(msg,".%d%dcm",temp/10,temp%10);
        lcdString(msg);
    }else lcdString("Invalid");
    temp=0;
    T0OV=0;
    TMR0=0;
}

void main(void) {
    /*8MHz internal oscillator*/
    OSCCONbits.IRCF=7;
    lcdInit();
    /*RD7 as input*/
    PORTD=0;
    TRISD=0x80;
    /*Select system clock*/
    T0CS=0;
    /*Timer0 Prescaler*/
    PSA=0;
    /*Select 1:2 Prescaler*/
    OPTION_REGbits.PS=0;
    /*Enable Timer0 Interrupt*/
    T0IE=1;
    GIE=1;
    T0IF=0;
    
    lcdXY(5,1);
    lcdString("PIC16F887 ");
    lcdXY(1,2);
    lcdString("HC-SR04 Distance");
    lcdXY(2,3); lcdString("Sensor Example");
    lcdXY(2,4); lcdString("MPLABX IDE XC8");
    __delay_ms(2000);
    lcdCommand(0x0C);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdXY(5,1);
    lcdString("Distance: ");
    lcdXY(1,3);
    lcdString("TIMER0 Duration:");
    TMR0=0;
    while(1){
        if(myCounter>=5000){
            readDistance();
            myCounter=0;
        }
    }
    return;
}


