/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 21, 2024, 7:12 PM
 */

#include <xc.h>
#include "config.h"
#include "mcp23017.h"

const uint8_t d_7[]={0x3F,0x06,0x5B,0x4F,
                     0x66,0x6D,0x7D,0x07,
                     0x7F,0x6F,0x77,0x7C,
                     0x39,0x5E,0x79,0x71};
const uint8_t key_16[][4]={7,8,9,15,
                           4,5,6,14, 
                           1,2,3,13,
                           10,0,11,12};

uint8_t keyScan(void){
    uint8_t data,temp;
    for(uint8_t i=0;i<4;i++){
        data=1<<i;
        mcp23017_write(OLATB,data);
        __delay_ms(10);
        data=mcp23017_read(GPIOB);
        data>>=4;
        if(data==0x01) {temp=key_16[i][0]; break;}
        else if(data==0x02) {temp=key_16[i][1]; break;}
        else if(data==0x04) {temp=key_16[i][2]; break;}
        else if(data==0x08) {temp=key_16[i][3]; break;}
        else temp=0xFF;
        __delay_ms(10);
    }
    return temp;
}
void main(void) {
    OSCCONbits.IRCF=7;
    __delay_ms(100);
    mcp23017_init();
    uint8_t temp=0xFF;
    while(1){
        temp=keyScan();
        if(temp!=0xFF){
            mcp23017_write(OLATA,d_7[temp]);
            __delay_ms(100);
        }
    }
    return;
}
