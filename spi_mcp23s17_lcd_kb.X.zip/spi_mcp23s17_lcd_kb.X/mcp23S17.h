/* 
 * File:   mcp23S17.h
 * Author: Admin
 *
 * Created on February 9, 2024, 3:54 PM
 */

#include <xc.h>
#include "spi.h"

/*MCP23S17 Registers Definition*/
#define IODIRA      0x00
#define IODIRB      0x01
#define IPOLA       0x02
#define IPOLB       0x03
#define GPINTENA    0x04
#define GPINTENB    0x05
#define DEFVALA     0x06
#define DEFVALB     0x07
#define INTCONA     0x08
#define INTCONB     0x09
#define IOCONA      0x0A
#define IOCONB      0x0B
#define GPPUA       0x0C
#define GPPUB       0x0D
#define INTFA       0x0E
#define INTFB       0x0F
#define INTCAPA     0x10
#define INTCAPB     0x11
#define GPIOA       0x12
#define GPIOB       0x13
#define OLATA       0x14
#define OLATB       0x15

/*MCP23S17 Address*/
#define WRITE_ADDR  0x40
#define READ_ADDR   0x41

/*MCP23S17 Read and Write Functions*/
void mcp23S17_send(uint8_t address, uint8_t data);
uint8_t mcp23S17_receive(uint8_t address);

/*MCP23S17 Character LCD Functions*/
#define RS  0
#define EN  2
void lcd_command(uint8_t command);
void lcd_data(uint8_t myChar);
void lcd_xy(uint8_t x, uint8_t y);
void lcd_text(uint8_t *txt);
void lcd_clear(void);
void lcd_init(void);

