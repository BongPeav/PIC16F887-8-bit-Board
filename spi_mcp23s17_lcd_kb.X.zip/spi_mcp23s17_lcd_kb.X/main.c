/*
 * File:   main.c
 * Author: Admin
 *
 * Created on February 11, 2024, 10:42 AM
 */

#include <xc.h>
#include "config.h"
#include "mcp23S17.h"

#define _XTAL_FREQ  8000000UL

/*MCP23S17 4x4 KeyPad Scan Function*/
const uint8_t key_ascii[][4]={
'7','8','9','/',
'4','5','6','*',
'1','2','3','-',
'x','0','=','+'
};
uint8_t get_key(void);

void main(void) {
    uint8_t key=0,char_count=0, new_line=0,line_num=1;
    OSCCONbits.IRCF=7;
    lcd_init();
    lcd_text("PIC16F887   MCP23S17");
    lcd_xy(1,2); lcd_text("Character LCD KeyPad");
    lcd_xy(1,3); lcd_text("Example Using MPLABX");
    lcd_xy(1,4); lcd_text("IDE And XC8 Compiler");
    __delay_ms(3000);
    lcd_clear();
    while(1){
        key=get_key();
        if(key!=0){
            lcd_data(key);
            __delay_ms(250);
            char_count+=1;
        }
        if(char_count>=20){char_count=0; new_line=1;}
        if(new_line){
            new_line=0;
            line_num+=1;
            switch(line_num){
                case 2: lcd_xy(1,2); break;
                case 3: lcd_xy(1,3); break;
                case 4: lcd_xy(1,4); break;
                case 5: lcd_clear(); line_num=1; break;
            }
        }
    }
}

uint8_t get_key(void){
    uint8_t data,key_value=0;
    for(uint8_t i=0;i<4;i++){
        mcp23S17_send(OLATB,1<<i);
        __delay_ms(10);
        data=mcp23S17_receive(GPIOB);
        data=data>>4;
        if(data==0x01) {key_value=key_ascii[i][0]; break;}
        else if(data==0x02) {key_value=key_ascii[i][1]; break;}
        else if(data==0x04) {key_value=key_ascii[i][2]; break;}
        else if(data==0x08) {key_value=key_ascii[i][3]; break;}
        else key_value=0;
    }
    return key_value;
}