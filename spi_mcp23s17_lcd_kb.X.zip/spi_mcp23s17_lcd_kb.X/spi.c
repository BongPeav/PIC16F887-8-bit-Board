
#include "spi.h"

void spi_init(void){
    /*SPI Mode Clock Low To High*/
    SSPCONbits.CKP=0;
    SSPSTATbits.CKE=1;
    SSPSTATbits.SMP=0;
    /*SPI Master Mode Clock = Fosc/4*/
    SSPCONbits.SSPM=0;
    /*Turn On The Module*/
    SSPCONbits.SSPEN=1;
    SSPSTATbits.BF=1;
    PORTC=0;
    TRISC=0;
    /*SPI SDI Pin Input*/
    TRISC4=1;
}

void spi_send(uint8_t data){
    SSPSTATbits.BF==1;
    SSPBUF=data;
    while(SSPSTATbits.BF==0);
    SSPSTATbits.BF==1;
}

uint8_t spi_receive(void){
    uint8_t data;
    spi_send(0x00);
    data=SSPBUF;
    return data;
}