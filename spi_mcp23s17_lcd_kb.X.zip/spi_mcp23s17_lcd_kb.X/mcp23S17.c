
#include "mcp23S17.h"

/*MCP23S17 Input Output Functions*/
void mcp23S17_send(uint8_t address, uint8_t data){
    nCS=0;
    spi_send(WRITE_ADDR);
    spi_send(address);
    spi_send(data);
    nCS=1;
}

uint8_t mcp23S17_receive(uint8_t address){
    uint8_t data;
    nCS=0;
    spi_send(READ_ADDR);
    spi_send(address);
    data=spi_receive();
    nCS=1;  
    return data;
}

/*MCP23S17 Character LCD Functions*/
void delay(uint16_t count){
    while(count>0) count--;
}
void lcd_command(uint8_t command){
    uint8_t data;
    data=command&0xF0;
    mcp23S17_send(OLATA, data|(1<<EN));
    delay(50);
    mcp23S17_send(OLATA, data);
    delay(50);
    
    data=command<<4;
    mcp23S17_send(OLATA, data|(1<<EN));
    delay(50);
    mcp23S17_send(OLATA, data);
    delay(50);
}

void lcd_data(uint8_t myChar){
    uint8_t data;
    data=myChar&0xF0;
    mcp23S17_send(OLATA, data|(1<<RS)|(1<<EN));
    delay(50);
    mcp23S17_send(OLATA, data);
    delay(50);
    
    data=myChar<<4;
    mcp23S17_send(OLATA, data|(1<<RS)|(1<<EN));
    delay(50);
    mcp23S17_send(OLATA, data|(1<<RS));
    delay(50);
}

void lcd_xy(uint8_t x, uint8_t y){
    /*20x4 Character LCD*/
    uint8_t tbe[]={0x80,0xC0,0x94,0xD4};
    lcd_command(tbe[y-1]+x-1);
}

void lcd_text(uint8_t *txt){
    while(*txt) lcd_data(*txt++);
}

void lcd_init(void){
    spi_init();
    nCS=1;
    /*LCD PORT*/
    mcp23S17_send(IODIRA,0x00);
    mcp23S17_send(OLATA,0x00);
    /*KeyPad PORT*/
    mcp23S17_send(IODIRB,0xF0);
    
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0F);
    lcd_command(0x01);
    delay(500);
    lcd_command(0x06);
}

void lcd_clear(void){
    lcd_command(0x01);
    delay(500);
}

