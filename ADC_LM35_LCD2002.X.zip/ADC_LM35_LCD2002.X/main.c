/*
 * File:   main.c
 * Author: Admin
 *
 * Created on December 22, 2023, 2:59 PM
 */


#include <xc.h>
#include "config.h"

#define _XTAL_FREQ 8000000UL

#include "lcd.h"
#include <stdio.h>

void main(void) {
    /*8MHz Internal OSC*/
    OSCCONbits.IRCF=7;
    /*Internal ADC FOSC*/
    ADCON0bits.ADCS=3;
    /*Select AN4*/
    ADCON0bits.CHS=4;
    __delay_ms(10);
    /*Turn On ADC*/
    ADCON0bits.ADON=1;
    /*Right Justify*/
    ADCON1bits.ADFM=1;
    /*VDD and VSS VFRE*/
    ADCON1bits.VCFG1=0;
    ADCON1bits.VCFG0=0;
    
    lcdInit();
    PORTA=0;
    TRISA5=1;
    lcdString("Temperature:");
    double temp=0;
    char message[16];
    lcdCommand(0x0C);
    __delay_ms(1000);
    while(1){
        ADCON0bits.GO=1;
        while(ADCON0bits.GO==0);
        temp=((ADRESH<<8)+ADRESL);
        temp=100*(5.0*temp/1023);
        sprintf(message,"%3.2f%cC   ",temp,223);
        lcdXY(1,2); lcdString(message);
        lcdXY(1,3); lcdString("On-Board LM35DZ");
        lcdXY(1,4); lcdString("Connects To RA5");
        __delay_ms(250);
    }
    return;
}
