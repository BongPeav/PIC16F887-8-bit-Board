/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 12, 2024, 3:08 PM
 */

#include <xc.h>
#include "config.h"
#include "tm1637.h"

#define _XTAL_FREQ  8000000UL

const char msg_1[]={0x76,0x79,0x38,0x38,0x3F};

void main(void) {
    char txt[7],count=0;
    OSCCONbits.IRCF=7;
    TM1637Init();
    for(uint8_t i=0;i<5;i++) display(i,msg_1[i]);
    __delay_ms(3000);
    clearDisplay();
    while(1){
        txt[6]=data_7[count];
        for(uint8_t i=0;i<6;i++) txt[i]=txt[i+1];
        /*
        txt[6]=data_7[count];
        txt[0]=txt[1];
        txt[1]=txt[2];
        txt[2]=txt[3];
        txt[3]=txt[4];
        txt[4]=txt[5];
        txt[5]=txt[6]; 
         */
        for(uint8_t i=0;i<6;i++) display(i,txt[i]);
        count++;
        __delay_ms(1000);
        if(count==16) count=0;
    }
    return;
}
