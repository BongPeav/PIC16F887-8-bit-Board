/*
 * File:   tm1637.c
 * Author: Admin
 *
 * Created on January 11, 2024, 9:31 PM
 */

#include "tm1637.h"

void start(void){
    CLK=1;
    DIO=1;
    DIO=0;
    CLK=0;
}
void stop(void){
    CLK=0;
    DIO=0;
    CLK=1;
    DIO=1;
}

void writeByte(int8_t data){
    uint8_t i, count1;
    for(i=0;i<8;i++){
        CLK=0;
        if(data&0x01) DIO=1;
        else DIO=0;
        data>>=1;
        CLK=1;
    }
    CLK=0;
    DIO=1;
    CLK=1;
    DIO_DIR=1;
    while(DIO==1){
        count1+=1;
        if(count1==200){
            DIO_DIR=0;
            DIO=0;
            count1=0;
        }
        DIO_DIR=1;
    }
    DIO_DIR=0;
}

void display(int8_t address, int8_t data){
    start();
    writeByte(ADDR_FIXED);
    stop();
    start();
    writeByte(STARTADDR|address);
    writeByte(data);
    stop();
    start();
    writeByte(MEDIUM_BRIGHT);
    stop();
}

void clearDisplay(void){
    for(int8_t i=0;i<6;i++) display(i,0);
}

void TM1637Init(void){
    PORTD=0;
    TRISD=0;
    DIO=1;
    CLK=1;
    clearDisplay();
}
