/*
 * File:   mcp23017.c
 * Author: Admin
 *
 * Created on January 21, 2024, 7:14 PM
 */

#include "mcp23017.h"

void mcp23017_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t mcp23017_read(uint8_t address){
    uint8_t data;
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_stop();
    
    i2c_start();
    i2c_write(MCP23017_R);
    data=i2c_read(0);
    i2c_stop();
    return data;
}

void mcp23017_init(void){
    i2c_init(40000);
    mcp23017_write(IODIRA,0);
    mcp23017_write(OLATA,0x08);
}