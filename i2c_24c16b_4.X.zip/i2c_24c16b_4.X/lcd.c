/*
 * File:   lcd.c
 * Author: Admin
 *
 * Created on December 21, 2023, 7:42 PM
 */

#include <xc.h>
#include "lcd.h"

void lcdCommand(char command){
    DB=command>>4;
    RW=0;
    RS=0;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
    
    DB=command&0x0F;
    RS=0;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
}

void lcdData(char data){
    DB=data>>4;
    RW=0;
    RS=1;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
    
    DB=data&0x0F;
    RS=1;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
}

void lcdString(char *str){
    while(*str) lcdData(*str++);
}

void lcdXY(char x, char y){
    char addr[]={0x80,0xC0,0x90,0xD0};
    lcdCommand(addr[y-1]+x-1);
}

void lcdInit(void){
    ANSELH=0;
    DB=0;
    CB=0;
    DR=0;
    CR=0;
    __delay_ms(10);
    lcdCommand(0x33);
    lcdCommand(0x32);
    lcdCommand(0x28);
    lcdCommand(0x0F);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdCommand(0x06);
}

