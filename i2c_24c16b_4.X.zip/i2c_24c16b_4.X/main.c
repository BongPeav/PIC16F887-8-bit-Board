/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 5, 2024, 9:50 AM
 */

#include <xc.h>
#include "config.h"
#include "i2c.h"
#include "lcd.h"

const write_address=0xA0;
const read_address=0xA1;

uint16_t write_24c16(uint16_t address,uint8_t *data){
    uint16_t write_size=0;
    i2c_start();
    i2c_write(write_address);
    i2c_write(0);
    while(*data){
        i2c_write(*data++);   
        write_size++;
        while(WCOL);
    }
    i2c_stop();
    return write_size;   
}

uint8_t *read_24c16(uint16_t address, uint16_t size){
    uint8_t temp[16];
    for(uint16_t i=0;i<sizeof(temp);i++) temp[i]='\0';
    for(uint8_t i=0;i<size;i++){
        i2c_start();
        i2c_write(write_address);
        i2c_write(i);
        i2c_stop();
      
        i2c_start();
        i2c_write(read_address);  
        temp[i]=i2c_read(0);  
        i2c_stop();
    }
    return temp; 
}

void main(void) {
    OSCCONbits.IRCF=7;
    lcdInit();
    i2c_init(1000);
    uint16_t length=0;    
    lcdCommand(0x0C);
    __delay_ms(100);
    
    length=write_24c16(0,"PIC16F887 24C16B");
    __delay_ms(10);
    lcdString(read_24c16(0,length));
    
    lcdXY(1,2);
    length=write_24c16(20,"I2C Programming");
    __delay_ms(10);
    lcdString(read_24c16(20,length));
    
    lcdXY(1,3);
    length=write_24c16(40,"With MPLABX IDE");
    __delay_ms(10);
    lcdString(read_24c16(40,length));
    
    lcdXY(1,4);
    length=write_24c16(60,"XC8 C Compiler");
    __delay_ms(10);
    lcdString(read_24c16(60,length));
    
    while(1);
    return;
}
