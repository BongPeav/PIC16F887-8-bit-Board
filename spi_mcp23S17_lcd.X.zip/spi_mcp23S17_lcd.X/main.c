/*
 * File:   main.c
 * Author: Admin
 *
 * Created on February 9, 2024, 3:47 PM
 */

#include <xc.h>
#include "config.h"
#include "mcp23S17.h"

#define _XTAL_FREQ  8000000UL

#define RS  0
#define EN  2

void lcd_command(uint8_t command){
    uint8_t data;
    data=command&0xF0;
    mcp23S17_send(OLATA, data|(1<<EN));
    __delay_us(50);
    mcp23S17_send(OLATA, data);
    __delay_us(50);
    
    data=command<<4;
    mcp23S17_send(OLATA, data|(1<<EN));
    __delay_us(50);
    mcp23S17_send(OLATA, data);
    __delay_us(50);
}

void lcd_data(uint8_t myChar){
    uint8_t data;
    data=myChar&0xF0;
    mcp23S17_send(OLATA, data|(1<<RS)|(1<<EN));
    __delay_us(50);
    mcp23S17_send(OLATA, data);
    __delay_us(50);
    
    data=myChar<<4;
    mcp23S17_send(OLATA, data|(1<<RS)|(1<<EN));
    __delay_us(50);
    mcp23S17_send(OLATA, data|(1<<RS));
    __delay_us(50);
}

void lcd_xy(uint8_t x, uint8_t y){
    /*20x4 Character LCD*/
    uint8_t tbe[]={0x80,0xC0,0x94,0xD4};
    lcd_command(tbe[y-1]+x-1);
}

void lcd_text(uint8_t *txt){
    while(*txt) lcd_data(*txt++);
}

void lcd_init(void){
    spi_init();
    nCS=1;
    mcp23S17_send(IODIRA,0x00);
    mcp23S17_send(OLATA,0x00);
    
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0F);
    lcd_command(0x01);
    __delay_ms(5);
    lcd_command(0x06);
}

void main(void) {
    OSCCONbits.IRCF=7;
    lcd_init();
    lcd_xy(2,1);
    lcd_text("PIC16F887 MCP23S17");
    lcd_xy(2,2);
    lcd_text("SPI GPIO Extender");
    lcd_xy(2,3);
    lcd_text("Example With MPLABX");
    lcd_xy(1,4);
    lcd_text("And XC8 C Compiler..");
    
    while(1){
        
    }
    return;
}
