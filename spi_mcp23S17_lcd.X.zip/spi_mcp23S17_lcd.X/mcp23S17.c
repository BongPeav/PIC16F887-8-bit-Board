
#include "mcp23S17.h"

void mcp23S17_send(uint8_t address, uint8_t data){
    nCS=0;
    spi_send(WRITE_ADDR);
    spi_send(address);
    spi_send(data);
    nCS=1;
}

uint8_t mcp23S17_receive(uint8_t address){
    uint8_t data;
    nCS=0;
    spi_send(READ_ADDR);
    spi_send(address);
    data=spi_receive();
    nCS=1;  
    return data;
}