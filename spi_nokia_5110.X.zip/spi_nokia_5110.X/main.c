
#include <xc.h>
#include "config.h"
#include "pcd8544.h"
#include "graphic_84x48.h"

#define _XTAL_FREQ  8000000UL

void main(void){
    OSCCONbits.IRCF=7;
    lcd_initialize();
    lcd_fill(0x00);
      
    while(1){
        for(uint16_t i=0;i<sizeof(graphic_84x48);i++)
        lcd_write(LCD_D,graphic_84x48[i]);
        __delay_ms(5000);
        lcd_fill(0);
        lcd_text("PIC16F887");
        lcd_new_line();
        lcd_text("Nokia 5110");
        lcd_new_line();
        lcd_text("LCD Example");
        lcd_new_line();
        lcd_text("Using MPLABX");
        lcd_text("XC8 Compiler");
        lcd_text("   BLOGGER  ");
        __delay_ms(5000);
        lcd_fill(0);
    }
}
