/*
 * File:   main.c
 * Author: Admin
 *
 * Created on December 27, 2023, 10:01 AM
 * PIC16F887 DHT-11 Temperature and Humidity Sensor
 * MPLABX IDE v6.15 and XC8 v2.36
 */

#include <xc.h>
#include "config.h"
#include "lcd.h"
#include <stdio.h>

#define _XTAL_FREQ 8000000UL

#define DATA_PIN    RD7
#define DATA_DIR    TRISD7

char data[5];
void readDHT11(void){
    for(char i=0;i<5;i++) data[i]=0;
    DATA_DIR=0;
    DATA_PIN=1;
    __delay_ms(10);
    DATA_PIN=0;
    __delay_ms(18);
    DATA_PIN=1;
    __delay_us(30);
    DATA_PIN=0;
    DATA_DIR=1;
    __delay_us(10);
    while(DATA_PIN==0);
    __delay_us(10);
    while(DATA_PIN==1);
    __delay_us(10);
    
    /*Start of Reception*/
    for(char i=0;i<5;i++){
        for(char j=0;j<8;j++){
            __delay_us(5);
            while(DATA_PIN==0);
            __delay_us(50);
            if(DATA_PIN==1){data[i]|=1<<7-j; while(DATA_PIN==1);}
        }
        //__delay_us(10);
    }
    /*CheckSum Calculation*/
    char checksum=data[0]+data[1]+data[2]+data[3];
    if(checksum!=data[4]){
        for(char i=0;i<4;i++) data[i]=0;
        return;
    }
    __delay_us(10);
}

void main(void) {
    OSCCONbits.IRCF=7;
    char msg[4];
    lcdInit();
    lcdXY(3,1);
    lcdString("DHT-11 Sensor");
    lcdXY(1,2);
    lcdString("Temperature and");
    lcdXY(1,3);
    lcdString("Humidity Reading");
    lcdXY(1,4);
    lcdString("with PIC16F887.");
    __delay_ms(2500);
    lcdCommand(0x0C);
    lcdCommand(0x01);
    __delay_ms(5);
    
    lcdXY(3,1);
    lcdString("DHT-11 Data");
    lcdXY(1,2);
    lcdString("Temperature: ");
    lcdXY(1,3);
    lcdString("Humidity   :");
    lcdXY(1,4);
    lcdString("CheckSum   : ");
   
    while(1){
        readDHT11();
        sprintf(msg,"%2dRH",data[0]);
        lcdXY(13,3); lcdString(msg);
        sprintf(msg,"%2d%cC",data[2],223);
        lcdXY(13,2); lcdString(msg);
        sprintf(msg,"%3d",data[4]);
        lcdXY(13,4); lcdString(msg);
        __delay_ms(500);
    }
    return;
}
