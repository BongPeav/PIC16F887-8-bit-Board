/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 8, 2024, 8:50 PM
 */

#include <xc.h>
#include "config.h"
#include "sh1106.h"

#define _XTAL_FREQ 20000000UL

void main(void) {
    display_init();
    __delay_ms(100);
    display_clear(0);
    display_text_8x16(0,0,"SH1106 I2C OLED");
    display_text_8x16(0,1,"And PIC16F887");
    display_text_8x16(0,2,"Programming With");
    display_text_8x16(0,3,"MPLABX IDE XC8");
    __delay_ms(5000);
    display_clear(0);
    while(1){
        display_text_8x16(0,0,"PIC16F887 SH1106");
        __delay_ms(2500);
        uint8_t h=15;
        for(uint8_t i=0;i<10;i++) {
            display_char_8x16(h,1,'0'+i);
            h+=10;
        }
        __delay_ms(2500);
        h=0;
        for(uint8_t i=0;i<14;i++) {
            display_char_8x16(h,2,'A'+i);
            h+=10;
        }
        __delay_ms(2500);
        h=0;
        for(uint8_t i=0;i<14;i++) {
            display_char_8x16(h,3,'N'+i);
            h+=10;
        }
        __delay_ms(10000);
        display_clear(255);
        __delay_ms(10000);
        display_clear(0);
        __delay_ms(1000);
    }
    return;
}
