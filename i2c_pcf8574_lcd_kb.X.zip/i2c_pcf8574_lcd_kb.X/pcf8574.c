/*
 * File:   pcf8574.c
 * Author: Admin
 *
 * Created on January 17, 2024, 3:38 PM
 */


#include "pcf8574.h"

/*PCF8574*/
//#define PCF8574_W   0x40
//#define PCF8574_R   0x41

/*PCF8574A*/
#define PCF8574_W   0x70
#define PCF8574_R   0x71

void pcf8574Write(uint8_t data){
    i2c_start();
    i2c_write(PCF8574_W);
    i2c_write(0x20);
    i2c_write(data);
    i2c_stop();
}


uint8_t pcf8574Read(){
    uint8_t data;  
    i2c_start();
    i2c_write(PCF8574_R);
    data=i2c_read(0);
    i2c_stop();
    return data;
}
