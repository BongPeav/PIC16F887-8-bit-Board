/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 17, 2024, 9:07 PM
 */

#include <xc.h>
#include "config.h"
#include "lcd.h"
#include "pcf8574.h"

#define _XTAL_FREQ  8000000UL

uint8_t key_16[][4]={'1','2','3','A',
                     '4','5','6','B',
                     '7','8','9','C',
                     '*','0','#','D'};

uint8_t keyScan(void){
    char data=0,temp,key;
    for(uint8_t i=0;i<4;i++){
        data=0xFF;
        data&=~(1<<i);
        pcf8574Write(data);
        __delay_ms(5);
        data=pcf8574Read();
        data&=0xF0;
        if((data&0x10)==0)     {temp=key_16[i][0]; break;}
        else if((data&0x20)==0){temp=key_16[i][1]; break;}
        else if((data&0x40)==0){temp=key_16[i][2]; break;}
        else if((data&0x80)==0){temp=key_16[i][3]; break;}
        else temp=0;
        __delay_ms(10);
    }
    return temp;
}

void main(void) {
    OSCCONbits.IRCF=7;
    i2c_init(100000);
    lcdInit();
    __delay_ms(100);
    uint8_t temp,charCount=0,newLine=0,line=1;
    while(1){
        temp=keyScan();
        if(temp!=0){
            lcdData(temp);  
            charCount++;
            __delay_ms(250);
        }
        if(charCount>=16){
            newLine=1;
            charCount=0;
            line+=1;
        }
        if(newLine){
            newLine=0;
            if(line==2) lcdXY(1,2);
            else if(line==3) lcdXY(1,3);
            else if(line==4) lcdXY(1,4);
            else{
                lcdCommand(0x01);
                __delay_ms(5);
                line=1;
            }
        }
    }
    return;
}
