/*
 * File:   main.c
 * Author: Admin
 *
 * Created on December 24, 2023, 5:56 PM
 * PIC16F887 DS18B20 and LCD Example
 * MPLABX IDE v6.15
 * XC8 v2.36
 */


#include <xc.h>
#include "config.h"
#include "lcd.h"
#include "ds18b20.h"

#define _XTAL_FREQ 8000000UL

unsigned char byte[10];
unsigned char TH=0,TL=0;

void sensorRead(void){
    ow_reset();
    writeByte(0xCC);
    writeByte(0x44);
    __delay_us(104);
    ow_reset();
    writeByte(0xCC);
    writeByte(0xBE);
    for(int i=0;i<9;i++) byte[i]=readByte();
    TH=byte[1];
    TL=byte[0];
    __delay_ms(10);
}

void main(void) {
    OSCCONbits.IRCF=7;
    PORTD=0;
    TRISD=0;
    lcdInit();  lcdString("PIC16F887 LCD");
    lcdXY(1,2); lcdString("DS18B20 1-Wire");
    lcdXY(1,3); lcdString("Programming With");
    lcdXY(1,4); lcdString("MPLABX IDE XC8");
    __delay_ms(2500);
    lcdCommand(0x0C);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdXY(3,1); lcdString("Temperature:");
    lcdXY(1,3); lcdString("DS18B20 Connects");
    lcdXY(1,4); lcdString("Pin RD7.");
    int temp=0, fraction=0;
    while(1){
        sensorRead();
        temp=(TH<<8)+TL;
        TH=temp>>4;
        lcdXY(1,2); lcdString("1Wire: ");
        if(temp&0x8000){
            temp=~temp+1;
            TH=temp>>4;
            TH&=0x7F;
            lcdData('-');
            lcdData(48+TH/10);
            lcdData(48+TH%10);
        }else{
            lcdData((TH>=100)?(48+TH/100):' ');
            lcdData((TH>=10)?(48+(TH%100)/10):' ');
            lcdData(48+TH%10);
        }
        fraction=temp&0x000F;
        fraction*=625;
        lcdData('.');
        lcdData(48+fraction/1000);
        lcdData(48+(fraction%1000)/100);
        lcdData(223);
        lcdData('C');
        __delay_ms(500);
    }
    return;
}
