
#include <xc.h>
#include "ds18b20.h"

unsigned char ow_reset(void){
    unsigned char presence;
    DQ_DIR=0;
    DQ=0;
    __delay_us(480);
    DQ=1;
    __delay_us(70);
    DQ_DIR=1;
    presence=DQ;
    __delay_us(425);
    return presence;
}

unsigned char readBit(void){
    DQ_DIR=0;
    DQ=0;
    DQ_DIR=1;
    __delay_us(15);
    return DQ;
}

void writeBit(char bitVal){
    DQ_DIR=0;
    DQ=0;
    if(bitVal==1) DQ=1;
    __delay_us(104);
    DQ=1;
}

unsigned char readByte(void){
    unsigned char i;
    unsigned char value=0;
    for(i=0;i<8;i++){
        if(readBit()) value|=0x01<<i;
        __delay_us(96);
    }
    return value;
}

void writeByte(char val){
    unsigned char i;
    unsigned char temp;
    for(i=0;i<8;i++){
        temp=val>>i;
        temp&=0x01;
        writeBit(temp);
    }
    __delay_us(104);
}