/* 
 * File:   ds18b20.h
 * Author: Admin
 *
 * Created on September 19, 2023, 1:00 PM
 */

#ifndef DS18B20_H
#define	DS18B20_H

#ifdef	__cplusplus
extern "C" {
#endif


#ifdef	__cplusplus
}
#endif

#define _XTAL_FREQ 8000000UL

#define DQ RD7
#define DQ_DIR TRISD7

unsigned char ow_reset(void);
unsigned char readBit(void);
void writeBit(char bitVal);
unsigned char readByte(void);
void writeByte(char val);
#endif	/* DS18B20_H */

