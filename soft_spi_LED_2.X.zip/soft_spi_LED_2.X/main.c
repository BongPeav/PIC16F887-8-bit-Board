/*
 * File:   main.c
 * Author: Admin
 *
 * Created on February 17, 2024, 6:59 PM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  8000000UL

#define CS  RC2
#define SCK RC3
#define SDI RC4
#define SDO RC5

const char EWEN = 0x04;
const char READ = 0x06;
const char WRITE= 0x05;

const char clock_time=1;

void spi_write(uint8_t data){
    for(int8_t i=7;i>=0;i--){
        SCK=0;
        if(data&(1<<i)) SDO=1;
        else SDO=0;
         __delay_us(clock_time);
        SCK=1;
        __delay_us(clock_time);
    }
    SCK=0;
    SDO=0;
}

void spi_write_16(uint16_t data){
    for(int8_t i=15;i>=0;i--){
        SCK=0;
        if(data&(1<<i)) SDO=1;
        else SDO=0;
         __delay_us(clock_time);
        SCK=1;
        __delay_us(clock_time);
    }
    SCK=0;
    SDO=0;
}

void write_93AA46B(uint8_t address, uint16_t data){    
    CS=1;
    spi_write(EWEN);
    spi_write(0xC0);
    CS=0;
    __delay_us(100);
    CS=1;
    spi_write(WRITE);
    spi_write(address);
    spi_write_16(data);
    CS=0;
    __delay_ms(10);
}

uint16_t read_93AA46B(uint8_t address){
    uint16_t data_h=0,data_l=0,data=0;
 
    CS=1;
    spi_write(READ);
    spi_write(address);  
    __delay_us(clock_time);
    
    for(int16_t i=16;i>=0;i--){
        SCK=0;
        if(SDI==1) data|=(1<<i);      
        __delay_us(clock_time);
        SCK=1;
        __delay_us(clock_time);    
    }
    CS=0;
    SCK=0;
    return data;
}

void main(void) {
    uint16_t data=0;
    OSCCONbits.IRCF=7;
    PORTC=0;
    TRISC=0x00;
    TRISC4=1;
    PORTD=0;
    TRISD=0;
    
    while(1){
        for(uint8_t i=0;i<8;i++){
            uint16_t temp=(1<<i)<<8;
            write_93AA46B(i,temp);           
            data=read_93AA46B(i);
            PORTD=data>>8;
            __delay_ms(100);         
        }
        PORTD=0;
        __delay_ms(2000);
        for(uint16_t i=0;i<255;i++){
            write_93AA46B(0,i<<8);           
            data=read_93AA46B(0);
            PORTD=data>>8;
            __delay_ms(100);
        }
        PORTD=0;
        __delay_ms(2000);
    }
    return;
}

