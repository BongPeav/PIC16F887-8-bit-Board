/*
 * File:   main.c
 * Author: Admin
 *
 * Created on January 21, 2024, 4:16 PM
 */

#include <xc.h>
#include "config.h"
#include "i2c.h"

#define _XTAL_FREQ  8000000UL

#define MCP23017_W  0x40
#define MCP23017_R  0x41

#define IODIRA      0x00
#define IODIRB      0x01
#define GPPUB       0x0D
#define GPIOB       0x13
#define OLATA       0x14

void mcp23017_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t mcp23017_read(uint8_t address){
    uint8_t data;
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_stop();
    
    i2c_start();
    i2c_write(MCP23017_R);
    data=i2c_read(0);
    i2c_stop();
    return data;
}

void main(void) {
    OSCCONbits.IRCF=7;
    i2c_init(400000);
    mcp23017_write(IODIRA,0);       //GPA AS OUTPUT
    mcp23017_write(IODIRB,0xFF);    //GPB AS INPUT
    mcp23017_write(GPPUB,0xFF);     //GPB PULL-UP ENABLE
    while(1){
        //READ GPB INPUT DATA
        uint8_t temp=mcp23017_read(GPIOB);
        __delay_ms(10);
        //WRITE GPA OUTPUT DATA
        mcp23017_write(OLATA,temp);
        __delay_ms(50);
    }
    return;
}
