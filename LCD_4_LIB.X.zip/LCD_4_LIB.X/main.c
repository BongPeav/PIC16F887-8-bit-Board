/*
 * File:   main.c
 * Author: Admin
 *
 * Created on December 21, 2023, 7:41 PM
 */


#include <xc.h>
#include "config.h"

#define _XTAL_FREQ 8000000UL

#include "lcd.h"
#include <stdio.h>

void main(void) {
    OSCCONbits.IRCF=7;
    lcdInit();
    lcdString("PIC16F887 8-BIT");
    lcdXY(1,2);
    lcdString("TC1604A-01(A) ");
    lcdXY(1,3);
    lcdString("LCD Interfacing");
    lcdXY(1,4); lcdString("With MPLABX XC8");
    __delay_ms(2500);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdCommand(0x0C);
    lcdXY(4,1);
    lcdString("Up Time:");
    char seconds=0,minutes=0,hours=0;
    int days=0;
    char message[16];  
    while(1){
        if(seconds>59){seconds=0; minutes++;}
        if(minutes>59){minutes=0; hours++;}
        if(hours>23){hours=0; days++;}
        sprintf(message,"Days : %4d",days);
        lcdXY(1,2); lcdString(message);
        sprintf(message,"Times: %2d:%2d:%2d",hours,minutes,seconds);
        lcdXY(1,3); lcdString(message);
        seconds++;
        __delay_ms(1000);
    }
    return;
}
